// 存储笔记的数据结构
let notes = [];
let currentNoteId = null;
let imageCounter = 0; // 添加图片计数器
const MAX_STORAGE_ITEM_SIZE = 5242880; // Chrome存储项目大小限制约为5MB
let storageType = 'chrome'; // 可以是 'chrome' 或 'local' (localStorage)
let activeTagFilters = []; // 当前激活的标签筛选
let searchQuery = ''; // 当前搜索查询
let searchType = 'all'; // 当前搜索类型

// 检查环境并决定使用哪种存储方式
function checkEnvironment() {
    console.log('检查运行环境...');
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        console.log('使用Chrome存储API');
        storageType = 'chrome';
        return true;
    } else {
        console.log('使用localStorage作为备选存储方式');
        storageType = 'local';
        return false;
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    console.log('页面开始初始化...');
    // 检查环境
    checkEnvironment();
    
    initializeApp();
    initPreviewFeature();
    initImagePasting(); // 初始化图片粘贴功能
    initMarked(); // 初始化Markdown渲染器
    initTagsSystem(); // 初始化标签系统
    initSearchSystem(); // 初始化搜索系统
    
    // 在加载笔记后进行标签修复
    setTimeout(repairNoteTagsProperty, 1000);
});

// 初始化预览功能
function initPreviewFeature() {
    console.log('初始化预览功能...');
    const viewButtons = document.querySelectorAll('.view-btn');
    const editor = document.querySelector('.editor');
    const preview = document.querySelector('.preview');
    const markdownEditor = document.querySelector('#markdown-editor');

    viewButtons.forEach(button => {
        button.addEventListener('click', () => {
            try {
                // 切换按钮激活状态
                viewButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');

                // 根据按钮文本切换视图
                if (button.textContent === '预览') {
                    editor.style.display = 'none';
                    preview.style.display = 'block';
                    // 确保marked已初始化
                    if (!window.markedInitialized) {
                        initMarked();
                        window.markedInitialized = true;
                    }
                    // 转换 Markdown 为 HTML 并显示
                    const markdownContent = markdownEditor.value;
                    const htmlContent = renderMarkdown(markdownContent);
                    preview.innerHTML = htmlContent;
                    console.log('预览已更新');
                } else {
                    editor.style.display = 'block';
                    preview.style.display = 'none';
                }
            } catch (error) {
                console.error('切换视图错误:', error);
                alert('切换预览视图失败: ' + error.message);
            }
        });
    });

    // 编辑器内容变化时自动更新预览
    markdownEditor.addEventListener('input', () => {
        try {
            if (preview.style.display === 'block') {
                const markdownContent = markdownEditor.value;
                const htmlContent = renderMarkdown(markdownContent);
                preview.innerHTML = htmlContent;
            }
        } catch (error) {
            console.error('预览更新错误:', error);
        }
    });
}

// 初始化应用
function initializeApp() {
    console.log('正在初始化应用...');
    initNewNoteButton();
    initDeleteNoteEvents();
    initSaveNoteEvents();
    initNotesList();
    loadNotes();
}

// 初始化新建笔记按钮
function initNewNoteButton() {
    console.log('初始化新建笔记按钮...');
    const newNoteBtn = document.querySelector('.new-note-btn');
    if (newNoteBtn) {
        newNoteBtn.addEventListener('click', createNewNote);
        console.log('新建笔记按钮初始化完成');
    } else {
        console.error('未找到新建笔记按钮');
    }
}

// 初始化删除笔记事件
function initDeleteNoteEvents() {
    console.log('初始化删除笔记事件...');
    const notesList = document.querySelector('.notes-list');
    if (notesList) {
        notesList.onclick = function(event) {
            const deleteBtn = event.target.closest('.delete-btn');
            if (deleteBtn) {
                console.log('点击了删除按钮');
                const noteItem = deleteBtn.closest('.note-item');
                if (noteItem) {
                    const noteId = parseInt(noteItem.dataset.id);
                    console.log('准备删除笔记，ID:', noteId);
                    deleteNote(noteId);
                }
            }
        };
        console.log('删除笔记事件初始化完成');
    }
}

// 初始化保存笔记事件
function initSaveNoteEvents() {
    console.log('初始化保存笔记事件...');
    // 获取保存按钮和编辑器
    const saveBtn = document.querySelector('.save-btn');
    const editor = document.querySelector('#markdown-editor');
    
    if (saveBtn && editor) {
        // 绑定保存按钮点击事件
        saveBtn.addEventListener('click', () => {
            console.log('点击了保存按钮');
            if (currentNoteId) {
                saveNoteContent(currentNoteId, editor.value);
            } else {
                console.warn('没有选中的笔记');
                alert('请先选择一个笔记再保存');
            }
        });

        // 绑定编辑器内容变化事件
        editor.addEventListener('input', () => {
            console.log('编辑器内容发生变化');
            if (currentNoteId) {
                // 自动保存功能
                saveNoteContent(currentNoteId, editor.value);
            }
        });

        console.log('保存笔记事件初始化完成');
    } else {
        console.error('未找到保存按钮或编辑器，saveBtn:', !!saveBtn, 'editor:', !!editor);
    }
}

// 初始化笔记列表
function initNotesList() {
    console.log('初始化笔记列表...');
    const notesList = document.querySelector('.notes-list');
    if (notesList) {
        notesList.addEventListener('click', (e) => {
            if (!e.target.matches('.delete-btn')) {
                const noteItem = e.target.closest('.note-item');
                if (noteItem) {
                    const noteId = parseInt(noteItem.dataset.id);
                    selectNote(noteId);
                }
            }
        });
        console.log('笔记列表初始化完成');
    }
}

// 初始化标签系统
function initTagsSystem() {
    console.log('初始化标签系统...');
    
    // 监听标签输入框，按回车添加标签
    const tagsInput = document.getElementById('tags-input');
    if (tagsInput) {
        tagsInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && tagsInput.value.trim()) {
                e.preventDefault();
                const tagValue = tagsInput.value.trim();
                console.log('通过回车添加标签:', tagValue);
                addTagToCurrentNote(tagValue);
                tagsInput.value = '';
            }
        });
    }
    
    // 添加标签按钮点击事件
    const addTagBtn = document.getElementById('add-tag-btn');
    if (addTagBtn) {
        addTagBtn.addEventListener('click', () => {
            const tagsInput = document.getElementById('tags-input');
            if (tagsInput && tagsInput.value.trim()) {
                const tagValue = tagsInput.value.trim();
                console.log('通过按钮添加标签:', tagValue);
                addTagToCurrentNote(tagValue);
                tagsInput.value = '';
            } else {
                showToast('请输入标签内容');
            }
        });
    }
    
    // 监听当前标签区域的点击事件（用于删除标签）
    const currentTags = document.getElementById('current-tags');
    if (currentTags) {
        currentTags.addEventListener('click', (e) => {
            if (e.target.classList.contains('tag-remove')) {
                const tagElement = e.target.closest('.tag-badge');
                if (tagElement && tagElement.dataset.tag) {
                    removeTagFromCurrentNote(tagElement.dataset.tag);
                }
            }
        });
    }
    
    // 监听标签列表的点击事件（用于筛选笔记）
    const tagList = document.getElementById('tag-list');
    if (tagList) {
        tagList.addEventListener('click', (e) => {
            const tagItem = e.target.closest('.tag-item');
            if (tagItem && tagItem.dataset.tag) {
                toggleTagFilter(tagItem.dataset.tag);
            }
        });
    }
    
    // 添加清除所有筛选的功能
    const tagFilterHeader = document.querySelector('.tag-filter-header');
    if (tagFilterHeader) {
        // 创建清除筛选按钮
        const clearButton = document.createElement('span');
        clearButton.className = 'clear-filters';
        clearButton.textContent = '清除筛选';
        clearButton.style.display = 'none'; // 默认隐藏
        clearButton.style.marginLeft = '10px';
        clearButton.style.fontSize = '12px';
        clearButton.style.color = '#4e94ce';
        clearButton.style.cursor = 'pointer';
        tagFilterHeader.appendChild(clearButton);
        
        // 监听清除筛选点击事件
        clearButton.addEventListener('click', () => {
            activeTagFilters = [];
            updateTagFilterUI();
            filterAndRenderNotes();
        });
    }
    
    // 初始时强制更新一次当前标签显示
    setTimeout(updateCurrentTagsDisplay, 500);
}

// 初始化搜索系统
function initSearchSystem() {
    console.log('初始化搜索系统...');
    
    // 监听搜索输入
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            searchQuery = e.target.value.trim();
            filterAndRenderNotes();
        });
    }
    
    // 监听搜索类型变化
    const searchTypeSelect = document.getElementById('search-type');
    if (searchTypeSelect) {
        searchTypeSelect.addEventListener('change', (e) => {
            searchType = e.target.value;
            filterAndRenderNotes();
        });
    }
}

// 添加诊断函数来检查标签保存问题
function debugTagStorage() {
    console.group('标签存储诊断');
    console.log('当前笔记总数:', notes.length);
    
    // 检查笔记对象中的标签
    let notesWithTags = 0;
    let totalTags = 0;
    
    notes.forEach((note, index) => {
        if (note.tags && Array.isArray(note.tags) && note.tags.length > 0) {
            notesWithTags++;
            totalTags += note.tags.length;
            console.log(`笔记 ${index+1} (ID: ${note.id}):`, note.title, '标签:', note.tags);
        }
    });
    
    console.log(`有标签的笔记: ${notesWithTags}/${notes.length}, 总标签数: ${totalTags}`);
    console.groupEnd();
}

// 为当前笔记添加标签
function addTagToCurrentNote(tag) {
    if (!currentNoteId) {
        showToast('请先选择或创建一个笔记');
        return;
    }
    
    const note = notes.find(n => n.id === currentNoteId);
    if (!note) {
        console.error('未找到当前笔记');
        return;
    }
    
    // 初始化标签数组（如果不存在）
    if (!note.tags) {
        note.tags = [];
    }
    
    // 转换为小写并检查是否已有该标签
    tag = tag.toLowerCase();
    if (note.tags.includes(tag)) {
        showToast(`标签 "${tag}" 已存在`);
        return;
    }
    
    // 添加新标签
    note.tags.push(tag);
    note.updatedAt = new Date().toLocaleString('zh-CN');
    
    console.log(`为笔记 ${note.id} 添加标签:`, tag, '当前标签:', note.tags);
    
    // 更新当前标签显示
    updateCurrentTagsDisplay();
    
    // 保存更新
    saveAndRender();
    
    showToast(`已添加标签 "${tag}"`);
}

// 从当前笔记移除标签
function removeTagFromCurrentNote(tag) {
    if (!currentNoteId) return;
    
    const note = notes.find(n => n.id === currentNoteId);
    if (!note || !note.tags) {
        return;
    }
    
    // 移除标签
    note.tags = note.tags.filter(t => t !== tag);
    note.updatedAt = new Date().toLocaleString('zh-CN');
    
    // 保存更新
    saveAndRender();
    
    // 更新当前标签显示
    updateCurrentTagsDisplay();
    
    showToast(`已移除标签 "${tag}"`);
}

// 更新当前笔记的标签显示
function updateCurrentTagsDisplay() {
    console.log('更新当前标签显示...');
    const currentTagsContainer = document.getElementById('current-tags');
    if (!currentTagsContainer) {
        console.error('未找到标签容器元素');
        return;
    }
    
    // 清空当前显示
    currentTagsContainer.innerHTML = '';
    
    // 如果没有选中的笔记，直接返回
    if (!currentNoteId) {
        currentTagsContainer.innerHTML = '<span class="no-tags">未选择笔记</span>';
        return;
    }
    
    const note = notes.find(n => n.id === currentNoteId);
    if (!note) {
        console.error('找不到当前选择的笔记');
        currentTagsContainer.innerHTML = '<span class="no-tags">找不到笔记</span>';
        return;
    }
    
    if (!note.tags) {
        note.tags = [];
    }
    
    console.log('当前笔记ID:', currentNoteId, '标签:', note.tags);
    
    // 如果没有标签
    if (!note.tags || note.tags.length === 0) {
        currentTagsContainer.innerHTML = '<span class="no-tags">没有标签</span>';
        return;
    }
    
    // 添加每个标签
    note.tags.forEach(tag => {
        if (!tag || typeof tag !== 'string') {
            console.warn('发现无效标签:', tag);
            return;
        }
        
        const tagElement = document.createElement('div');
        tagElement.className = 'tag-badge';
        tagElement.dataset.tag = tag;
        tagElement.innerHTML = `
            <span class="tag-text">${tag}</span>
            <span class="tag-remove">×</span>
        `;
        currentTagsContainer.appendChild(tagElement);
    });
    
    // 确保父容器可见
    const tagsWrapper = document.querySelector('.current-tags-wrapper');
    if (tagsWrapper) {
        tagsWrapper.style.display = 'block';
    }
}

// 更新标签筛选UI
function updateTagFilterUI() {
    const tagItems = document.querySelectorAll('.tag-item');
    tagItems.forEach(item => {
        const tag = item.dataset.tag;
        if (activeTagFilters.includes(tag)) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });
    
    // 更新清除筛选按钮的显示状态
    const clearButton = document.querySelector('.clear-filters');
    if (clearButton) {
        clearButton.style.display = activeTagFilters.length > 0 ? 'inline' : 'none';
    }
    
    // 更新筛选状态提示
    const filterStatus = document.querySelector('.filter-status');
    if (!filterStatus && activeTagFilters.length > 0) {
        // 如果不存在筛选状态提示，则创建一个
        const tagFilterSection = document.querySelector('.tag-filter');
        if (tagFilterSection) {
            const statusElement = document.createElement('div');
            statusElement.className = 'filter-status';
            statusElement.textContent = `当前筛选: ${activeTagFilters.join(', ')}`;
            statusElement.style.fontSize = '12px';
            statusElement.style.color = '#999';
            statusElement.style.marginTop = '10px';
            tagFilterSection.appendChild(statusElement);
        }
    } else if (filterStatus) {
        // 如果已存在筛选状态提示，则更新内容
        if (activeTagFilters.length > 0) {
            filterStatus.textContent = `当前筛选: ${activeTagFilters.join(', ')}`;
            filterStatus.style.display = 'block';
        } else {
            filterStatus.style.display = 'none';
        }
    }
}

// 切换标签筛选
function toggleTagFilter(tag) {
    console.log('切换标签筛选:', tag);
    
    // 如果标签已在筛选列表中，则移除
    if (activeTagFilters.includes(tag)) {
        activeTagFilters = activeTagFilters.filter(t => t !== tag);
        console.log('移除标签筛选:', tag, '当前筛选:', activeTagFilters);
    } else {
        // 否则添加到筛选列表
        activeTagFilters.push(tag);
        console.log('添加标签筛选:', tag, '当前筛选:', activeTagFilters);
    }
    
    // 更新UI和笔记列表
    updateTagFilterUI();
    filterAndRenderNotes();
}

// 筛选并渲染笔记
function filterAndRenderNotes() {
    console.log('筛选和渲染笔记...');
    
    // 应用筛选条件
    const filteredNotes = notes.filter(note => {
        // 标签筛选
        if (activeTagFilters.length > 0) {
            if (!note.tags || !activeTagFilters.every(tag => note.tags.includes(tag))) {
                return false;
            }
        }
        
        // 搜索筛选
        if (searchQuery) {
            const query = searchQuery.toLowerCase();
            
            switch (searchType) {
                case 'title':
                    return note.title.toLowerCase().includes(query);
                case 'content':
                    return note.content.toLowerCase().includes(query);
                case 'tag':
                    return note.tags && note.tags.some(tag => tag.toLowerCase().includes(query));
                case 'all':
                default:
                    return (
                        note.title.toLowerCase().includes(query) || 
                        note.content.toLowerCase().includes(query) || 
                        (note.tags && note.tags.some(tag => tag.toLowerCase().includes(query)))
                    );
            }
        }
        
        return true;
    });
    
    console.log(`筛选结果: ${filteredNotes.length}/${notes.length} 条笔记`);
    
    // 渲染筛选后的笔记列表
    renderFilteredNotesList(filteredNotes);
}

// 渲染筛选后的笔记列表
function renderFilteredNotesList(filteredNotes) {
    const notesList = document.querySelector('.notes-list');
    if (!notesList) {
        console.error('未找到笔记列表容器');
        return;
    }
    
    if (filteredNotes.length === 0) {
        notesList.innerHTML = '<div class="no-notes">没有找到符合条件的笔记</div>';
        return;
    }
    
    notesList.innerHTML = filteredNotes.map(note => {
        // 高亮匹配的搜索词
        let title = note.title || '无标题';
        let preview = generateNotePreview(note.content);
        
        if (searchQuery) {
            const query = searchQuery.toLowerCase();
            
            // 根据搜索类型高亮不同部分
            if (searchType === 'all' || searchType === 'title') {
                title = highlightMatch(title, query);
            }
            
            if (searchType === 'all' || searchType === 'content') {
                preview = highlightMatch(preview, query);
            }
        }
        
        // 添加标签显示
        const tagsHtml = note.tags && note.tags.length > 0 
            ? `<div class="note-tags">${note.tags.map(tag => 
                `<span class="note-tag ${searchType === 'tag' && searchQuery && tag.toLowerCase().includes(searchQuery.toLowerCase()) ? 'highlight-match' : ''}">${tag}</span>`
              ).join('')}</div>` 
            : '';
        
        return `
            <div class="note-item ${note.id === currentNoteId ? 'selected' : ''}" data-id="${note.id}">
                <div class="note-info">
                    <div class="note-title">${title}</div>
                    <div class="note-preview">${preview}</div>
                    ${tagsHtml}
                    <div class="note-meta">
                        <span class="note-date">${note.updatedAt}</span>
                    </div>
                </div>
                <button class="delete-btn" type="button">删除</button>
            </div>
        `;
    }).join('');
}

// 高亮匹配的文本
function highlightMatch(text, query) {
    if (!query) return text;
    
    // 转义正则表达式特殊字符
    const escapedQuery = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escapedQuery})`, 'gi');
    
    return text.replace(regex, '<span class="highlight-match">$1</span>');
}

// 更新标签列表
function updateTagsList() {
    console.log('更新标签列表...');
    const tagListContainer = document.getElementById('tag-list');
    if (!tagListContainer) return;
    
    // 收集所有标签并计数
    const tagCounts = {};
    let totalTagsFound = 0;
    
    notes.forEach(note => {
        if (note.tags && Array.isArray(note.tags)) {
            note.tags.forEach(tag => {
                if (tag && typeof tag === 'string') {
                    tagCounts[tag] = (tagCounts[tag] || 0) + 1;
                    totalTagsFound++;
                }
            });
        }
    });
    
    console.log(`找到 ${Object.keys(tagCounts).length} 个不同标签，共 ${totalTagsFound} 个标签实例`);
    
    // 如果没有标签
    if (Object.keys(tagCounts).length === 0) {
        tagListContainer.innerHTML = '<div class="no-tags">暂无标签</div>';
        return;
    }
    
    // 按标签名称排序
    const sortedTags = Object.keys(tagCounts).sort();
    
    // 创建标签元素
    tagListContainer.innerHTML = sortedTags.map(tag => `
        <div class="tag-item ${activeTagFilters.includes(tag) ? 'active' : ''}" data-tag="${tag}">
            ${tag} (${tagCounts[tag]})
        </div>
    `).join('');
}

// 创建新笔记
function createNewNote() {
    console.log('创建新笔记...');
    const defaultContent = '# 新建笔记\n\n开始输入你的笔记内容...';
    
    const newNote = {
        id: Date.now(),
        title: '新建笔记',
        content: defaultContent,
        tags: [],  // 添加空标签数组
        createdAt: new Date().toLocaleString('zh-CN'),
        updatedAt: new Date().toLocaleString('zh-CN')
    };
    
    notes.unshift(newNote);
    currentNoteId = newNote.id;
    
    // 设置编辑器内容并聚焦
    const editor = document.querySelector('#markdown-editor');
    if (editor) {
        editor.value = defaultContent;
        editor.focus();
        // 将光标定位到内容开始处
        editor.setSelectionRange(defaultContent.length, defaultContent.length);
    }
    
    // 清空标签输入框
    const tagsInput = document.getElementById('tags-input');
    if (tagsInput) {
        tagsInput.value = '';
    }
    
    // 更新当前标签显示
    updateCurrentTagsDisplay();
    
    saveAndRender();
    console.log('新笔记创建完成，ID:', newNote.id);
}

// 保存笔记内容
function saveNoteContent(noteId, content) {
    console.log('保存笔记内容，ID:', noteId);
    const note = notes.find(n => n.id === noteId);
    if (note) {
        note.content = content;
        // 确保笔记有tags属性
        if (!note.tags) {
            note.tags = [];
        }
        // 更新笔记标题
        note.title = extractTitleFromContent(content);
        note.updatedAt = new Date().toLocaleString('zh-CN');
        
        // 确保标签显示正常更新
        updateCurrentTagsDisplay();
        
        saveAndRender();
        console.log('笔记内容和标题已保存，标签:', note.tags);
    } else {
        console.error('未找到要保存的笔记');
        alert('保存失败：未找到笔记');
    }
}

// 从内容中提取标题
function extractTitleFromContent(content) {
    if (!content) return '新建笔记';
    
    // 尝试匹配 Markdown 标题格式
    const titleMatch = content.match(/^#\s+(.+)$|^(.+?)\n|^(.+)$/m);
    if (titleMatch) {
        // 获取第一个非空的匹配组
        const title = titleMatch[1] || titleMatch[2] || titleMatch[3];
        // 限制标题长度为30个字符
        return title.trim().substring(0, 30);
    }
    
    return '新建笔记';
}

// 删除笔记
function deleteNote(noteId) {
    console.log('删除笔记，ID:', noteId);
    if (confirm('确定要删除这条笔记吗？')) {
        // 找到要删除的笔记，检查其标签
        const noteToDelete = notes.find(note => note.id === noteId);
        if (noteToDelete && noteToDelete.tags && noteToDelete.tags.length > 0) {
            console.log(`删除的笔记有 ${noteToDelete.tags.length} 个标签:`, noteToDelete.tags);
        }
        
        notes = notes.filter(note => note.id !== noteId);
        if (currentNoteId === noteId) {
            currentNoteId = null;
            const editor = document.querySelector('#markdown-editor');
            if (editor) {
                editor.value = '';
            }
            // 清空当前标签显示
            updateCurrentTagsDisplay();
        }
        saveAndRender();
        console.log('笔记已删除');
    }
}

// 选择笔记
function selectNote(noteId) {
    console.log('选择笔记，ID:', noteId);
    currentNoteId = noteId;
    const note = notes.find(n => n.id === noteId);
    const editor = document.querySelector('#markdown-editor');
    
    if (note && editor) {
        editor.value = note.content;
        
        // 清空标签输入框
        const tagsInput = document.getElementById('tags-input');
        if (tagsInput) {
            tagsInput.value = '';
        }
        
        // 立即更新当前标签显示
        updateCurrentTagsDisplay();
        
        // 更新选中状态
        renderNotesList();
        console.log('笔记内容已加载到编辑器，标签:', note.tags);
    }
}

// 保存并重新渲染
function saveAndRender() {
    console.log('保存并重新渲染...');
    saveNotesToStorage(() => {
        updateTagsList(); // 更新标签列表
        updateCurrentTagsDisplay(); // 确保当前笔记的标签显示正确
        filterAndRenderNotes(); // 使用筛选功能渲染笔记列表
        console.log('保存和渲染完成');
    });
}

// 保存笔记到存储
function saveNotesToStorage(callback) {
    console.log('保存笔记到存储...');
    try {
        // 检查标签情况
        debugTagStorage();
        
        // 添加错误处理和大小检查
        let totalSize = 0;
        notes.forEach(note => {
            // 确保每个笔记都有tags属性
            if (!note.tags) {
                note.tags = [];
            }
            
            // 计算每个笔记的近似大小
            const noteSize = JSON.stringify(note).length;
            totalSize += noteSize;
            
            // 如果单个笔记超过限制，记录警告
            if (noteSize > MAX_STORAGE_ITEM_SIZE) {
                console.warn(`笔记 ${note.id} 太大 (约 ${Math.round(noteSize/1024)}KB)，可能无法保存`);
            }
        });
        
        console.log(`总数据大小约为: ${Math.round(totalSize/1024)}KB`);
        
        // 根据环境选择存储方式
        if (storageType === 'chrome') {
            // Chrome存储API方式
            
            // 如果总大小超过5MB，尝试逐个保存笔记
            if (totalSize > MAX_STORAGE_ITEM_SIZE) {
                console.warn('笔记总大小超过限制，尝试分开存储...');
                // 实现单独存储每个笔记的逻辑
                saveNotesIndividually(callback);
                return;
            }
            
            // 正常保存全部笔记
            chrome.storage.local.set({ notes: notes }, () => {
                if (chrome.runtime.lastError) {
                    console.error('保存失败:', chrome.runtime.lastError);
                    handleStorageError(chrome.runtime.lastError, callback);
                    return;
                }
                console.log('保存成功, 包含标签的笔记数量:', notes.filter(n => n.tags && n.tags.length > 0).length);
                if (callback) callback();
            });
        } else {
            // localStorage方式
            try {
                // 如果总大小太大，分别存储每个笔记
                if (totalSize > 2 * 1024 * 1024) { // localStorage限制通常为5MB，这里限制为2MB以安全
                    saveNotesToLocalStorageIndividually(callback);
                    return;
                }
                
                localStorage.setItem('md_notes', JSON.stringify(notes));
                console.log('笔记已保存到localStorage');
                if (callback) callback();
            } catch (e) {
                if (e.name === 'QuotaExceededError') {
                    console.warn('localStorage存储空间不足，尝试分开存储');
                    saveNotesToLocalStorageIndividually(callback);
                } else {
                    console.error('localStorage保存失败:', e);
                    alert('保存失败: ' + e.message);
                    if (callback) callback();
                }
            }
        }
    } catch (error) {
        console.error('保存出错:', error);
        alert('保存时发生错误: ' + error.message);
        if (callback) callback();
    }
}

// 保存笔记到localStorage (分别存储)
function saveNotesToLocalStorageIndividually(callback) {
    console.log('分别保存笔记到localStorage...');
    
    try {
        // 保存笔记索引
        const noteIndex = notes.map(note => ({
            id: note.id,
            title: note.title,
            createdAt: note.createdAt,
            updatedAt: note.updatedAt
        }));
        
        localStorage.setItem('md_note_index', JSON.stringify(noteIndex));
        
        // 逐个保存笔记
        let successCount = 0;
        let errorCount = 0;
        
        notes.forEach(note => {
            try {
                localStorage.setItem(`md_note_${note.id}`, JSON.stringify(note));
                successCount++;
            } catch (e) {
                errorCount++;
                console.error(`笔记 ${note.id} 保存失败:`, e);
            }
        });
        
        console.log(`保存完成: 成功 ${successCount}, 失败 ${errorCount}`);
        
        if (errorCount > 0) {
            alert(`部分笔记(${errorCount}个)保存失败，可能是因为内容过大`);
        }
        
        if (callback) callback();
    } catch (e) {
        console.error('保存笔记索引失败:', e);
        alert('保存失败: ' + e.message);
        if (callback) callback();
    }
}

// 处理存储错误
function handleStorageError(error, callback) {
    if (error.message && error.message.includes('QUOTA_BYTES')) {
        // 存储配额错误
        alert('笔记内容超出存储限制，请减少图片数量或大小');
    } else {
        alert('保存失败，请重试: ' + error.message);
    }
    
    if (callback) callback();
}

// 加载笔记列表
function loadNotes() {
    console.log('加载笔记列表...');
    
    try {
        if (storageType === 'chrome') {
            // 使用Chrome存储API
            // 先尝试常规加载方式
            chrome.storage.local.get(['notes', 'noteIndex'], (result) => {
                if (chrome.runtime.lastError) {
                    console.error('加载失败:', chrome.runtime.lastError);
                    alert('加载笔记失败: ' + chrome.runtime.lastError.message);
                    return;
                }
                
                // 如果存在常规笔记数组，直接使用
                if (result.notes && Array.isArray(result.notes)) {
                    notes = result.notes;
                    
                    // 确保每个笔记都有tags属性
                    notes.forEach(note => {
                        if (!note.tags) {
                            note.tags = [];
                        }
                    });
                    
                    console.log('已加载', notes.length, '条笔记');
                    
                    // 载入完成后更新UI
                    onNotesLoaded();
                    
                    renderNotesList();
                    return;
                }
                
                // 否则，检查是否有笔记索引
                if (result.noteIndex && Array.isArray(result.noteIndex)) {
                    console.log('使用索引加载笔记...');
                    loadNotesFromIndex(result.noteIndex);
                    return;
                }
                
                // 没有找到任何笔记数据
                notes = [];
                console.log('没有找到笔记，创建新的空列表');
                onNotesLoaded();
                renderNotesList();
            });
        } else {
            // 使用localStorage
            loadNotesFromLocalStorage();
            onNotesLoaded();
        }
    } catch (error) {
        console.error('加载出错:', error);
        alert('加载笔记失败: ' + error.message);
        // 尝试从localStorage加载作为备选方案
        if (storageType === 'chrome') {
            console.log('尝试从localStorage加载...');
            loadNotesFromLocalStorage();
            onNotesLoaded();
        }
    }
}

// 从索引加载笔记
function loadNotesFromIndex(noteIndex) {
    console.log('从索引加载', noteIndex.length, '条笔记...');
    
    // 初始化笔记数组使用索引中的基本信息
    notes = [...noteIndex];
    
    // 确保每个笔记都有tags属性
    notes.forEach(note => {
        if (!note.tags) {
            note.tags = [];
        }
    });
    
    // 使用Promise以便等待所有笔记加载完成
    const loadPromises = noteIndex.map(indexNote => {
        return new Promise((resolve) => {
            const noteKey = `note_${indexNote.id}`;
            
            chrome.storage.local.get([noteKey], (result) => {
                if (chrome.runtime.lastError) {
                    console.error(`加载笔记 ${indexNote.id} 失败:`, chrome.runtime.lastError);
                    resolve(); // 即使失败也继续
                    return;
                }
                
                // 如果找到了笔记内容，更新到笔记数组
                if (result[noteKey]) {
                    // 找到笔记在数组中的索引
                    const noteIndex = notes.findIndex(n => n.id === indexNote.id);
                    if (noteIndex !== -1) {
                        const loadedNote = result[noteKey];
                        // 确保加载的笔记有tags属性
                        if (!loadedNote.tags) {
                            loadedNote.tags = [];
                        }
                        
                        notes[noteIndex] = loadedNote;
                        console.log(`笔记 ${indexNote.id} 加载成功, 标签:`, loadedNote.tags);
                    }
                }
                
                resolve();
            });
        });
    });
    
    // 等待所有笔记加载完成后渲染列表
    Promise.all(loadPromises).then(() => {
        console.log('所有笔记加载完成');
        
        // 立即更新标签列表
        updateTagsList();
        
        renderNotesList();
    });
}

// 从localStorage加载笔记
function loadNotesFromLocalStorage() {
    console.log('从localStorage加载笔记...');
    
    try {
        // 先尝试加载完整笔记列表
        const notesJson = localStorage.getItem('md_notes');
        if (notesJson) {
            notes = JSON.parse(notesJson);
            
            // 确保每个笔记都有tags属性
            notes.forEach(note => {
                if (!note.tags) {
                    note.tags = [];
                }
            });
            
            console.log('从localStorage加载了', notes.length, '条笔记');
            
            // 立即更新标签列表
            updateTagsList();
            
            renderNotesList();
            return;
        }
        
        // 尝试加载笔记索引
        const noteIndexJson = localStorage.getItem('md_note_index');
        if (noteIndexJson) {
            const noteIndex = JSON.parse(noteIndexJson);
            console.log('从localStorage加载笔记索引，包含', noteIndex.length, '条笔记');
            
            // 根据索引加载单个笔记
            notes = [...noteIndex]; // 先用索引信息填充
            
            // 确保每个笔记都有tags属性
            notes.forEach(note => {
                if (!note.tags) {
                    note.tags = [];
                }
            });
            
            noteIndex.forEach(indexNote => {
                const noteJson = localStorage.getItem(`md_note_${indexNote.id}`);
                if (noteJson) {
                    try {
                        const noteData = JSON.parse(noteJson);
                        // 确保加载的笔记有tags属性
                        if (!noteData.tags) {
                            noteData.tags = [];
                        }
                        
                        // 更新到笔记数组
                        const noteIndex = notes.findIndex(n => n.id === indexNote.id);
                        if (noteIndex !== -1) {
                            notes[noteIndex] = noteData;
                        }
                    } catch (e) {
                        console.error(`解析笔记 ${indexNote.id} 失败:`, e);
                    }
                }
            });
            
            // 立即更新标签列表
            updateTagsList();
            
            renderNotesList();
            return;
        }
        
        // 没有找到任何笔记
        notes = [];
        console.log('localStorage中没有找到笔记');
        renderNotesList();
    } catch (e) {
        console.error('从localStorage加载失败:', e);
        notes = [];
        renderNotesList();
    }
}

// 渲染笔记列表
function renderNotesList() {
    // 使用筛选功能替代直接渲染
    filterAndRenderNotes();
}

// 生成笔记预览
function generateNotePreview(content) {
    if (!content) return '';
    
    // 移除Markdown标记
    let preview = content
        .replace(/^#+ /gm, '') // 移除标题标记
        .replace(/\*\*/g, '') // 移除粗体标记
        .replace(/\*/g, '') // 移除斜体标记
        .replace(/`{3}[\s\S]*?`{3}/g, '') // 移除代码块
        .replace(/`.*?`/g, '') // 移除行内代码
        .replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1') // 将链接转换为纯文本
        .replace(/^\s*[-*+]\s/gm, ''); // 移除列表标记
    
    // 获取第一行之后的内容（因为第一行通常是标题）
    const lines = preview.split('\n').filter(line => line.trim());
    if (lines.length > 1) {
        preview = lines.slice(1).join(' ').trim();
    } else {
        preview = lines[0] || '';
    }
    
    // 限制预览长度为50个字符
    return preview.length > 50 ? preview.substring(0, 50) + '...' : preview;
    
    console.log('笔记列表渲染完成');
}

// 初始化编辑器
function initializeEditor() {
    const editor = document.getElementById('markdown-editor');
    if (!editor) return;

    // 添加快捷键支持
    editor.addEventListener('keydown', function(e) {
        // Ctrl+T 插入表格
        if (e.ctrlKey && e.key === 't') {
            e.preventDefault();
            insertTable();
        }
    });
}

// 插入表格模板
function insertTable() {
    const editor = document.getElementById('markdown-editor');
    if (!editor) return;

    const tableTemplate = `
| 标题1 | 标题2 | 标题3 |
|-------|-------|-------|
| 内容1 | 内容2 | 内容3 |
| 内容4 | 内容5 | 内容6 |

`;

    // 获取当前光标位置
    const start = editor.selectionStart;
    const end = editor.selectionEnd;
    const content = editor.value;

    // 在光标位置插入表格模板
    editor.value = content.substring(0, start) + tableTemplate + content.substring(end);
    
    // 更新光标位置
    const newPosition = start + tableTemplate.length;
    editor.setSelectionRange(newPosition, newPosition);
    
    // 触发内容更新
    if (currentNoteId) {
        saveNoteContent(currentNoteId, editor.value);
    }

    // 提示用户
    showToast('已插入表格模板，使用 | 分隔列');
}

// 显示提示信息
function showToast(message) {
    console.log('显示提示:', message);
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 300);
        }, 2000);
    }, 100);
}

// 初始化 marked 配置
function initMarked() {
    console.log('初始化Markdown渲染器...');
    marked.setOptions({
        breaks: true,
        gfm: true,
        tables: true,
        headerIds: false,
        mangle: false,
        sanitize: false
    });

    // 自定义渲染器
    const renderer = new marked.Renderer();
    
    // 自定义表格渲染
    renderer.table = function(header, body) {
        return `
            <div class="table-container">
                <table class="markdown-table">
                    <thead>${header}</thead>
                    <tbody>${body}</tbody>
                </table>
            </div>
        `;
    };

    // 自定义图片渲染
    renderer.image = function(href, title, text) {
        console.log('渲染图片:', title || '无标题', '替代文本:', text || '无文本');
        return `<img src="${href}" alt="${text || '图片'}" title="${title || ''}" class="markdown-image" onerror="this.onerror=null;this.src='';this.alt='图片加载失败';this.classList.add('image-error');console.error('图片加载失败:', this.alt);">`;
    };

    // 设置渲染器
    marked.use({ renderer });
    
    // 设置标志防止重复初始化
    window.markedInitialized = true;
    console.log('Markdown渲染器初始化完成');
}

// 渲染Markdown为HTML
function renderMarkdown(content) {
    try {
        if (!content) return '';
        return marked.parse(content);
    } catch (error) {
        console.error('Markdown渲染错误:', error);
        return `<div class="error">渲染错误: ${error.message}</div>`;
    }
}

// 初始化图片粘贴功能
function initImagePasting() {
    console.log('初始化图片粘贴功能...');
    const editor = document.getElementById('markdown-editor');
    const imageUpload = document.getElementById('image-upload');
    const imageBtn = document.querySelector('.image-btn');

    // 点击图片按钮触发文件选择
    if (imageBtn) {
        imageBtn.addEventListener('click', () => {
            if (!currentNoteId) {
                showToast('请先选择或创建一个笔记');
                return;
            }
            imageUpload.click();
        });
    }

    // 监听编辑器的粘贴事件
    editor.addEventListener('paste', async (e) => {
        const clipboardItems = e.clipboardData.items;
        const items = Array.from(clipboardItems).filter(item => {
            return item.type.indexOf('image') !== -1;
        });

        if (items.length === 0) {
            console.log('剪贴板中没有图片');
            return; // 没有图片内容，使用默认粘贴行为
        }

        e.preventDefault(); // 阻止默认粘贴行为

        for (const item of items) {
            console.log('处理粘贴的图片...');
            const blob = item.getAsFile();
            await handleImagePaste(blob, editor);
        }
    });

    // 监听文件选择变化
    imageUpload.addEventListener('change', async (e) => {
        if (e.target.files.length > 0) {
            const file = e.target.files[0];
            await handleImagePaste(file, editor);
            // 重置文件输入，允许再次选择同一文件
            e.target.value = '';
        }
    });
}

// 处理图片粘贴
async function handleImagePaste(blob, editor) {
    if (!currentNoteId) {
        console.warn('没有选中的笔记');
        showToast('请先选择或创建一个笔记');
        return;
    }

    console.log('处理图片数据...', '类型:', blob.type, '大小:', Math.round(blob.size/1024), 'KB');
    try {
        // 检查图片类型
        const validImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp'];
        
        if (!validImageTypes.includes(blob.type)) {
            console.warn('不支持的图片类型:', blob.type);
            showToast('不支持的图片类型: ' + (blob.type || '未知类型'));
            return;
        }
        
        // 生成唯一的图片ID
        imageCounter++;
        const imageId = `${currentNoteId}_${Date.now()}_${imageCounter}`;
        
        // 转换图片为Base64并可能压缩
        const base64 = await convertAndOptimizeImage(blob);
        
        if (!base64) {
            throw new Error('图片处理失败');
        }

        console.log('图片转换为Base64完成，大小约:', Math.round(base64.length/1024), 'KB');
        
        // 估算图片大小
        const estimatedSize = base64.length * 2; // 粗略估计Base64字符串在存储中的大小
        if (estimatedSize > MAX_STORAGE_ITEM_SIZE) {
            showToast('图片太大，请使用更小的图片');
            console.warn('图片太大，超出存储限制');
            return;
        }
        
        // 生成Markdown图片标记
        const imageMarkdown = `![图片${imageCounter}](${base64})`;
        
        // 获取光标位置
        const cursorPos = editor.selectionStart;
        
        // 在光标位置插入图片Markdown
        const content = editor.value;
        editor.value = content.substring(0, cursorPos) + 
                        imageMarkdown + 
                        content.substring(cursorPos);
        
        // 更新光标位置
        const newPosition = cursorPos + imageMarkdown.length;
        editor.setSelectionRange(newPosition, newPosition);
        
        // 保存笔记内容
        saveNoteContent(currentNoteId, editor.value);
        
        showToast('图片已插入');
        console.log('图片已成功插入到笔记中');
    } catch (error) {
        console.error('处理图片失败:', error);
        showToast('图片处理失败: ' + error.message);
    }
}

// 将Blob转换为Base64并可能压缩图片
async function convertAndOptimizeImage(blob) {
    return new Promise((resolve, reject) => {
        try {
            // 创建一个文件读取器
            const reader = new FileReader();
            
            reader.onloadend = () => {
                // 文件读取完成后的base64数据
                const base64data = reader.result;
                console.log('图片读取完成，转换为Base64');
                
                // 如果文件小于500KB，直接返回，不做压缩
                if (blob.size < 512 * 1024) {
                    console.log('图片较小，不进行压缩');
                    resolve(base64data);
                    return;
                }
                
                // 创建一个图片元素用于压缩
                const img = new Image();
                img.onload = () => {
                    console.log('图片加载成功，开始压缩', '原始尺寸:', img.width, 'x', img.height);
                    // 创建canvas
                    const canvas = document.createElement('canvas');
                    // 计算新的尺寸，保持纵横比
                    let width = img.width;
                    let height = img.height;
                    
                    // 如果宽度大于800px，按比例缩小
                    if (width > 800) {
                        const ratio = 800 / width;
                        width = 800;
                        height = Math.round(height * ratio);
                    }
                    
                    canvas.width = width;
                    canvas.height = height;
                    
                    // 在canvas上绘制压缩后的图片
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);
                    
                    // 保持原始图片格式
                    let outputType = blob.type || 'image/jpeg';
                    let quality = 0.7;
                    
                    // PNG和GIF格式不支持质量参数
                    if (outputType === 'image/png' || outputType === 'image/gif') {
                        quality = undefined;
                    }
                    
                    // 将canvas转换为base64，使用较低的质量
                    const compressedBase64 = canvas.toDataURL(outputType, quality);
                    console.log('图片压缩完成，新尺寸:', width, 'x', height);
                    resolve(compressedBase64);
                };
                
                img.onerror = (e) => {
                    // 如果图片加载失败，返回原始base64
                    console.warn('图片压缩失败，使用原始数据', e);
                    resolve(base64data);
                };
                
                // 设置图片源
                img.src = base64data;
            };
            
            reader.onerror = (e) => {
                console.error('文件读取失败', e);
                reject(new Error('文件读取失败'));
            };
            
            // 开始读取文件
            reader.readAsDataURL(blob);
        } catch (error) {
            console.error('图片处理异常:', error);
            reject(error);
        }
    });
}

// 单独保存每个笔记到Chrome存储
function saveNotesIndividually(callback) {
    console.log('正在单独保存每个笔记到Chrome存储...');
    
    // 创建一个笔记索引
    const noteIndex = notes.map(note => ({
        id: note.id, 
        title: note.title,
        createdAt: note.createdAt,
        updatedAt: note.updatedAt,
        tags: note.tags || [] // 确保标签也被保存到索引中
    }));
    
    // 先保存索引
    chrome.storage.local.set({ noteIndex: noteIndex }, async () => {
        if (chrome.runtime.lastError) {
            console.error('保存笔记索引失败:', chrome.runtime.lastError);
            alert('保存失败: 无法创建笔记索引');
            if (callback) callback();
            return;
        }
        
        // 逐个保存笔记内容
        let errorOccurred = false;
        for (const note of notes) {
            // 确保笔记有tags属性
            if (!note.tags) {
                note.tags = [];
            }
            
            // 创建键值，使用 note_ 前缀加ID
            const noteKey = `note_${note.id}`;
            
            try {
                // 等待保存完成
                await new Promise((resolve, reject) => {
                    chrome.storage.local.set({ [noteKey]: note }, () => {
                        if (chrome.runtime.lastError) {
                            console.error(`保存笔记 ${note.id} 失败:`, chrome.runtime.lastError);
                            reject(chrome.runtime.lastError);
                        } else {
                            console.log(`笔记 ${note.id} 保存成功, 标签:`, note.tags);
                            resolve();
                        }
                    });
                });
            } catch (error) {
                errorOccurred = true;
                console.error(`保存笔记 ${note.id} 时出错:`, error);
                // 继续尝试保存其他笔记
            }
        }
        
        if (errorOccurred) {
            alert('部分笔记可能没有正确保存，请检查内容');
        } else {
            console.log('所有笔记保存成功');
        }
        
        if (callback) callback();
    });
}

// 添加一个新的辅助函数来确保所有笔记都有有效的标签属性
function repairNoteTagsProperty() {
    console.log('修复笔记标签属性...');
    let repairedCount = 0;
    
    notes.forEach(note => {
        // 如果标签不存在或不是数组，重置为空数组
        if (!note.tags || !Array.isArray(note.tags)) {
            note.tags = [];
            repairedCount++;
        } else {
            // 过滤无效标签（非字符串）
            const validTags = note.tags.filter(tag => tag && typeof tag === 'string');
            if (validTags.length !== note.tags.length) {
                note.tags = validTags;
                repairedCount++;
            }
        }
    });
    
    if (repairedCount > 0) {
        console.log(`已修复 ${repairedCount} 个笔记的标签属性`);
        saveAndRender();
    } else {
        console.log('所有笔记的标签属性均正常');
    }
}

// 加载笔记列表后添加一个回调来确保标签显示
function onNotesLoaded() {
    console.log('笔记加载完成，更新UI...');
    updateTagsList();
    updateCurrentTagsDisplay();
    if (currentNoteId) {
        // 如果有当前选择的笔记，确保它的标签正确显示
        const note = notes.find(n => n.id === currentNoteId);
        if (note) {
            console.log('当前笔记标签:', note.tags);
        }
    }
}
