// 监听插件图标点击事件
chrome.action.onClicked.addListener(() => {
    // 创建新窗口
    chrome.windows.create({
        url: 'popup.html',
        type: 'normal',
        state: 'maximized'
    });
});
